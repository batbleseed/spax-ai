#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════╗
║   S P A X  —  Your AI from Beyond the Stars     ║
╚══════════════════════════════════════════════════╝
Free & fast — powered by Groq (no GPU needed).

SETUP (run once):
  python -m pip install groq

Set your free Groq key (get one at console.groq.com):
  Windows PowerShell:
    $env:GROQ_API_KEY = "gsk_..."
  Mac/Linux:
    export GROQ_API_KEY="gsk_..."

Then run:
  python spax.py
"""

import sys
import os
import textwrap
import time
import threading

class C:
    RESET     = "\033[0m"
    BOLD      = "\033[1m"
    DIM       = "\033[2m"
    NEBULA    = "\033[38;5;135m"
    STARLIGHT = "\033[38;5;189m"
    COSMOS    = "\033[38;5;61m"
    PULSAR    = "\033[38;5;213m"
    COMET     = "\033[38;5;117m"
    SOLAR     = "\033[38;5;220m"
    ERROR     = "\033[38;5;203m"
    MUTED     = "\033[38;5;244m"
    GREEN     = "\033[38;5;120m"

def clear():
    os.system("cls" if os.name == "nt" else "clear")

def wrap(text, width=72, indent="   "):
    paragraphs = text.split("\n")
    wrapped = []
    for para in paragraphs:
        if para.strip() == "":
            wrapped.append("")
        else:
            wrapped.append(textwrap.fill(para, width=width,
                           initial_indent=indent, subsequent_indent=indent))
    return "\n".join(wrapped)

_FRAMES = ["✦", "✧", "⋆", "✺", "✻", "✼", "✽", "✧"]

class Loader:
    def __init__(self, msg=""):
        self.msg   = msg
        self._stop = threading.Event()
        self._t    = threading.Thread(target=self._spin, daemon=True)
    def _spin(self):
        i = 0
        while not self._stop.is_set():
            f = _FRAMES[i % len(_FRAMES)]
            print(f"\r   {C.PULSAR}{f}{C.RESET}  {C.DIM}{C.STARLIGHT}{self.msg}{C.RESET}   ",
                  end="", flush=True)
            time.sleep(0.13)
            i += 1
    def start(self): self._t.start()
    def stop(self):
        self._stop.set(); self._t.join()
        print("\r" + " " * 60 + "\r", end="", flush=True)

BANNER = f"""
{C.COSMOS}  ╔════════════════════════════════════════════════════════╗{C.RESET}
{C.NEBULA}  ║   ░ ▒ ▓  S  P  A  X  ▓ ▒ ░                          ║{C.RESET}
{C.STARLIGHT}  ║        Your AI Companion from Beyond the Stars         ║{C.RESET}
{C.COSMOS}  ╚════════════════════════════════════════════════════════╝{C.RESET}

  {C.MUTED}⋆ Type your message and press Enter   {C.SOLAR}help{C.MUTED} → commands
  ⋆ {C.SOLAR}clear{C.MUTED} → clear screen   {C.SOLAR}exit{C.MUTED} → end transmission{C.RESET}
"""
STARS = f"  {C.DIM}{C.STARLIGHT}·  ✦  ·    ·   ✧  ·    ·   ⋆  ·    ✦  ·   ✧  ·    ·  ⋆{C.RESET}"

HELP_TEXT = f"""
  {C.SOLAR}━━  SPAX COMMANDS  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{C.RESET}
  {C.COMET}help{C.RESET}        — show this panel
  {C.COMET}clear{C.RESET}       — clear screen
  {C.COMET}reset{C.RESET}       — wipe conversation memory
  {C.COMET}exit / quit{C.RESET} — end the session
  {C.SOLAR}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{C.RESET}
"""

SYSTEM_PROMPT = (
    "You are SPAX, a friendly and helpful AI assistant with a cosmic outer-space "
    "personality. You are brilliant, warm, and occasionally poetic — like starlight "
    "given a voice. You use subtle space metaphors but never overdo it. "
    "You are always genuinely helpful and give clear, direct answers. "
    "You address the user warmly, as a fellow explorer of the universe."
)

def main():
    try:
        from groq import Groq
    except ImportError:
        print(f"\n  {C.ERROR}✖  groq package not found.{C.RESET} Run:\n")
        print(f"  {C.COMET}  python -m pip install groq{C.RESET}\n")
        sys.exit(1)

    api_key = os.environ.get("GROQ_API_KEY", "")
    if not api_key:
        print(f"\n  {C.ERROR}✖  GROQ_API_KEY not set.{C.RESET}\n")
        print(f"  {C.MUTED}Get a free key at {C.COMET}console.groq.com{C.RESET}")
        print(f"  {C.MUTED}Then in PowerShell:{C.RESET}")
        print(f"  {C.COMET}  $env:GROQ_API_KEY = \"gsk_...\"{C.RESET}\n")
        sys.exit(1)

    client = Groq(api_key=api_key)
    history = []

    clear()
    print(BANNER)
    print(STARS)
    print(f"\n  {C.GREEN}✦  SPAX online. Awaiting transmission.{C.RESET}\n")

    while True:
        try:
            user_input = input(
                f"  {C.PULSAR}◈{C.RESET}  {C.BOLD}{C.STARLIGHT}You:{C.RESET}  "
            ).strip()
        except (EOFError, KeyboardInterrupt):
            print(f"\n\n  {C.NEBULA}✦  Safe travels, explorer. Until next orbit.{C.RESET}\n")
            break

        if not user_input:
            continue

        cmd = user_input.lower()
        if cmd in ("exit", "quit", "bye"):
            print(f"\n  {C.NEBULA}✦  Safe travels, explorer. Until next orbit.{C.RESET}\n")
            break
        elif cmd == "clear":
            clear(); print(BANNER); print(STARS)
            print(f"\n  {C.GREEN}✦  SPAX online. Awaiting transmission.{C.RESET}\n"); continue
        elif cmd == "reset":
            history.clear()
            print(f"  {C.MUTED}⟳  Memory cleared — new mission started.{C.RESET}\n"); continue
        elif cmd == "help":
            print(HELP_TEXT); continue

        history.append({"role": "user", "content": user_input})

        loader = Loader("SPAX is charting a course through the cosmos")
        loader.start()
        try:
            messages = [{"role": "system", "content": SYSTEM_PROMPT}] + history
            response = client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=messages,
                max_tokens=1024,
                temperature=0.75,
            )
            reply = response.choices[0].message.content
            history.append({"role": "assistant", "content": reply})
            loader.stop()
            print(f"\n  {C.SOLAR}✦{C.RESET}  {C.BOLD}{C.NEBULA}SPAX:{C.RESET}")
            print(f"{C.STARLIGHT}{wrap(reply)}{C.RESET}\n")
        except Exception as e:
            loader.stop()
            err = str(e)
            if "401" in err or "auth" in err.lower():
                print(f"\n  {C.ERROR}✖  Invalid API key. Check your GROQ_API_KEY.{C.RESET}\n")
            elif "429" in err:
                print(f"\n  {C.ERROR}✖  Rate limit hit. Wait a moment and try again.{C.RESET}\n")
            elif "connect" in err.lower() or "network" in err.lower():
                print(f"\n  {C.ERROR}✖  No connection. Check your internet signal.{C.RESET}\n")
            else:
                print(f"\n  {C.ERROR}✖  Anomaly detected: {e}{C.RESET}\n")

if __name__ == "__main__":
    main()
